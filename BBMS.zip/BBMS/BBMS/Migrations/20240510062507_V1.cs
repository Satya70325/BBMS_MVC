﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBMS.Migrations
{
    public partial class V1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BloodGroupTypes",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GroupName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BloodUnits = table.Column<long>(type: "bigint", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BloodGroupTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserRoles",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RoleId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserManagements",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserRoleRowId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserRoleId = table.Column<long>(type: "bigint", nullable: true),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PrimaryMobile = table.Column<long>(type: "bigint", nullable: false),
                    SecondaryMobile = table.Column<long>(type: "bigint", nullable: true),
                    PrimaryEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SecondaryEmail = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PinCode = table.Column<long>(type: "bigint", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PassWord = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserManagements", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UserManagements_UserRoles_UserRoleId",
                        column: x => x.UserRoleId,
                        principalTable: "UserRoles",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "BloodDonations",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserManagementRowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserManagementId = table.Column<long>(type: "bigint", nullable: true),
                    BloodGroupTypeRowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BloodGroupTypeId = table.Column<long>(type: "bigint", nullable: true),
                    DonationDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsDonarSubmitted = table.Column<bool>(type: "bit", nullable: false),
                    NumberofUnits = table.Column<long>(type: "bigint", nullable: false),
                    RBCCount = table.Column<long>(type: "bigint", nullable: false),
                    WBCCount = table.Column<long>(type: "bigint", nullable: false),
                    PlateletsCount = table.Column<long>(type: "bigint", nullable: false),
                    IsDonationDone = table.Column<bool>(type: "bit", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BloodDonations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BloodDonations_BloodGroupTypes_BloodGroupTypeId",
                        column: x => x.BloodGroupTypeId,
                        principalTable: "BloodGroupTypes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_BloodDonations_UserManagements_UserManagementId",
                        column: x => x.UserManagementId,
                        principalTable: "UserManagements",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "BloodOrders",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserManagementRowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserManagementId = table.Column<long>(type: "bigint", nullable: true),
                    BloodGroupTypeRowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BloodGroupTypeId = table.Column<long>(type: "bigint", nullable: true),
                    NoOfUnitsAvailable = table.Column<long>(type: "bigint", nullable: false),
                    NoOfUnitsRequired = table.Column<long>(type: "bigint", nullable: false),
                    UserRequested = table.Column<bool>(type: "bit", nullable: false),
                    UserCancelled = table.Column<bool>(type: "bit", nullable: false),
                    PaymentRecieved = table.Column<bool>(type: "bit", nullable: false),
                    StaffProcessed = table.Column<bool>(type: "bit", nullable: false),
                    StaffCancelled = table.Column<bool>(type: "bit", nullable: false),
                    SampleOutFordelivery = table.Column<bool>(type: "bit", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BloodOrders", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BloodOrders_BloodGroupTypes_BloodGroupTypeId",
                        column: x => x.BloodGroupTypeId,
                        principalTable: "BloodGroupTypes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_BloodOrders_UserManagements_UserManagementId",
                        column: x => x.UserManagementId,
                        principalTable: "UserManagements",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "InventoryDetail",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    InventoryNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InventoryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    BloodOrderId = table.Column<long>(type: "bigint", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InventoryDetail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_InventoryDetail_BloodOrders_BloodOrderId",
                        column: x => x.BloodOrderId,
                        principalTable: "BloodOrders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OrdeDeliveryDetail",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OutFordelivery = table.Column<bool>(type: "bit", nullable: false),
                    OutFordeliveryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeliveryPersonDetails = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    delivered = table.Column<bool>(type: "bit", nullable: false),
                    DeliveryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeliveryOTP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BloodOrderId = table.Column<long>(type: "bigint", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrdeDeliveryDetail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrdeDeliveryDetail_BloodOrders_BloodOrderId",
                        column: x => x.BloodOrderId,
                        principalTable: "BloodOrders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PaymentDetail",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PaymentRecieved = table.Column<bool>(type: "bit", nullable: false),
                    PaymentCancelled = table.Column<bool>(type: "bit", nullable: false),
                    PaymentDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PaymentAmount = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    TransactionNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TransactionDetails = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TransactionType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TransactionCardDetails = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BloodOrderId = table.Column<long>(type: "bigint", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PaymentDetail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PaymentDetail_BloodOrders_BloodOrderId",
                        column: x => x.BloodOrderId,
                        principalTable: "BloodOrders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "BloodGroupTypes",
                columns: new[] { "Id", "BloodUnits", "CreatedBy", "CreatedOn", "GroupName", "IsDeleted", "ModifiedBy", "ModifiedOn", "OrderBy", "RowId" },
                values: new object[,]
                {
                    { 1L, 0L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7323), "A+", false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7324), 0, "f2672e36-c1c3-4994-8652-cec737d058ef" },
                    { 2L, 0L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7329), "A-", false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7330), 0, "82aaec17-c59c-42b2-ac36-742624f11a20" },
                    { 3L, 0L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7334), "B+", false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7334), 0, "f65a95cc-0367-4e22-b1c4-357a71e5c984" },
                    { 4L, 0L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7338), "B-", false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7338), 0, "c6c29c93-ae06-4492-b8c0-203475664905" },
                    { 5L, 0L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7342), "AB+", false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7342), 0, "c57d194c-099a-4c5c-a36e-e684d31964d4" },
                    { 6L, 0L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7346), "AB-", false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7347), 0, "eb2684f2-fdda-4eeb-be76-7ff2ada61a64" },
                    { 7L, 0L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7351), "O+", false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7352), 0, "3fa699df-c3af-43a2-b8d3-0333f634ff55" },
                    { 8L, 0L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7361), "O-", false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7361), 0, "0f8a4551-d0d3-44c3-b265-8c726cb20e1f" }
                });

            migrationBuilder.InsertData(
                table: "UserRoles",
                columns: new[] { "Id", "CreatedBy", "CreatedOn", "IsDeleted", "ModifiedBy", "ModifiedOn", "OrderBy", "RoleId", "RoleName", "RowId" },
                values: new object[,]
                {
                    { 1L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7093), false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7104), 0, "1EA44CE7-667B-436A-982D-D419E74DE322", "Administrator", "4ec0181e-815b-4e95-84a4-2d86dd84aad9" },
                    { 2L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7110), false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7111), 0, "95117A42-6456-46A5-8ACB-0E0B0E0E8A96", "Staff", "47da6a10-9a42-468a-99f8-122542cf803f" },
                    { 3L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7115), false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7116), 0, "AAC21712-38EA-4CF7-A1BE-ACC0AEAEF72C", "Donor", "ff1fcc9a-7dd5-4d41-9534-953b950d090c" },
                    { 4L, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7120), false, "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7120), 0, "31C2282F-40E7-4A58-86FB-DCD73ADD4C01", "User", "d98431dc-0970-4693-a948-d67254e66b61" }
                });

            migrationBuilder.InsertData(
                table: "UserManagements",
                columns: new[] { "Id", "Address1", "Address2", "Address3", "CreatedBy", "CreatedOn", "FirstName", "IsDeleted", "LastName", "MiddleName", "ModifiedBy", "ModifiedOn", "OrderBy", "PassWord", "PinCode", "PrimaryEmail", "PrimaryMobile", "RowId", "SecondaryEmail", "SecondaryMobile", "UserName", "UserRoleId", "UserRoleRowId" },
                values: new object[] { 1L, "Administrator", "Administrator", "Administrator", "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7288), "Administrator", false, "Administrator", "Administrator", "Administrator", new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7289), 0, "Admin", 111111L, "Administrator@gmail.com", 1234567890L, "a38254bd-c35a-4108-b01a-cb29a192a16e", "Administrator@gmail.com", 1234567890L, "Admin", 1L, "1EA44CE7-667B-436A-982D-D419E74DE322" });

            migrationBuilder.CreateIndex(
                name: "IX_BloodDonations_BloodGroupTypeId",
                table: "BloodDonations",
                column: "BloodGroupTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_BloodDonations_UserManagementId",
                table: "BloodDonations",
                column: "UserManagementId");

            migrationBuilder.CreateIndex(
                name: "IX_BloodOrders_BloodGroupTypeId",
                table: "BloodOrders",
                column: "BloodGroupTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_BloodOrders_UserManagementId",
                table: "BloodOrders",
                column: "UserManagementId");

            migrationBuilder.CreateIndex(
                name: "IX_InventoryDetail_BloodOrderId",
                table: "InventoryDetail",
                column: "BloodOrderId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_OrdeDeliveryDetail_BloodOrderId",
                table: "OrdeDeliveryDetail",
                column: "BloodOrderId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PaymentDetail_BloodOrderId",
                table: "PaymentDetail",
                column: "BloodOrderId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserManagements_UserRoleId",
                table: "UserManagements",
                column: "UserRoleId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BloodDonations");

            migrationBuilder.DropTable(
                name: "InventoryDetail");

            migrationBuilder.DropTable(
                name: "OrdeDeliveryDetail");

            migrationBuilder.DropTable(
                name: "PaymentDetail");

            migrationBuilder.DropTable(
                name: "BloodOrders");

            migrationBuilder.DropTable(
                name: "BloodGroupTypes");

            migrationBuilder.DropTable(
                name: "UserManagements");

            migrationBuilder.DropTable(
                name: "UserRoles");
        }
    }
}
