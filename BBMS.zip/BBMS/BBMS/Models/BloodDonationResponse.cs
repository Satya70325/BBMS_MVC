﻿namespace BBMS.Models
{
    public class BloodDonationResponse
    {
        public string? Status { get; set; }
        public string? Msg { get; set; }
        public BloodDonation _bloodDonation { get; set; } = new BloodDonation();
        public List<BloodDonation> _bloodDonations { get; set; } = new List<BloodDonation>();
    }
}
