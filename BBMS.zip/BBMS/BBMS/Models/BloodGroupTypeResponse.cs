﻿namespace BBMS.Models
{
    public class BloodGroupTypeResponse
    {
        public string? Status { get; set; }
        public string? Msg { get; set; }
        public BloodGroupType _bloodGroupType { get; set; } = new BloodGroupType();
        public List<BloodGroupType> _bloodGroupTypes { get; set; } = new List<BloodGroupType>();
    }
}
