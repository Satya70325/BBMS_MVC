﻿namespace BBMS.Models
{
    public class BloodGroupType : BBMSBase
    {
        public string? GroupName { get; set; }
        public long BloodUnits { get; set; }
    }
}
