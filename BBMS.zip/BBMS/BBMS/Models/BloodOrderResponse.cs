﻿namespace BBMS.Models
{
    public class BloodOrderResponse
    {
        public string? Status { get; set; }
        public string? Msg { get; set; }
        public BloodOrder _bloodOrder { get; set; } = new BloodOrder();
        public List<BloodOrder> _bloodOrders { get; set; } = new List<BloodOrder>();
    }
}
