﻿namespace BBMS.Models
{
    public class UserManagementResponse
    {
        public string? Status { get; set; }
        public string? Msg { get; set; }
        public UserManagement _UserMgmt { get; set; } = new UserManagement();
        public List<UserManagement> _userManagement { get; set; } = new List<UserManagement>();
    }
}
