﻿using BBMS.Models;

namespace BBMS.Data.IRepository
{
    public interface IBloodGroupType
    {
        BloodGroupTypeResponse GetAllBloodGroupTypes();
        BloodGroupTypeResponse GetBloodGroupType(int id);
        BloodGroupTypeResponse AddBloodGroupType(BloodGroupType _bloodGroupType);
        BloodGroupTypeResponse UpdateBloodGroupType(BloodGroupType _bloodGroupType);
        BloodGroupTypeResponse DeleteBloodGroupType(BloodGroupType _bloodGroupType);
    }
}
