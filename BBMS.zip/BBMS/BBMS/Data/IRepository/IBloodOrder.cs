﻿using BBMS.Models;

namespace BBMS.Data.IRepository
{
    public interface IBloodOrder
    {
        BloodOrderResponse GetAllBloodOrders();
        BloodOrderResponse GetBloodOrder(int id);
        BloodOrderResponse AddBloodOrder(BloodOrder _bloodOrder);
        BloodOrderResponse UpdateBloodOrder(BloodOrder _bloodOrder);
        BloodOrderResponse DeleteBloodOrder(BloodOrder _bloodOrder);
    }
}
