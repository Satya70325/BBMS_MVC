﻿using BBMS.Models;

namespace BBMS.Data.IRepository
{
    public interface IBloodDonation
    {
        BloodDonationResponse GetAllBloodDonars();
        BloodDonationResponse GetBloodDonar(int id);
        BloodDonationResponse AddBloodDonar(BloodDonation _bloodDonation);
        BloodDonationResponse UpdateBloodDonar(BloodDonation _bloodDonation);
        BloodDonationResponse DeleteBloodDonar(BloodDonation _bloodDonation);
    }
}
