﻿using BBMS.Data.IRepository;
using BBMS.Models;
using Microsoft.EntityFrameworkCore;

namespace BBMS.Data.Repository
{
    public class BloodOrderRepository : IBloodOrder
    {
        private readonly BBMSDataContext _context;
        public BloodOrderRepository(BBMSDataContext context)
        {
            _context = context;
        }
       

        public BloodOrderResponse GetAllBloodOrders()
        {
            BloodOrderResponse BloodOrderrsp = new BloodOrderResponse();
            try
            {
                List<BloodOrder> GetAllBloodOrders = _context.BloodOrders.Where(s => !s.IsDeleted).ToList();

                if (GetAllBloodOrders.Any())
                {
                    List<BloodOrder> response = GetAllBloodOrders.Select(s => new BloodOrder()
                    {
                        Id = s.Id,
                        NoOfUnitsAvailable = s.NoOfUnitsAvailable,
                        NoOfUnitsRequired = s.NoOfUnitsRequired,
                        UserRequested = s.UserRequested,
                        UserCancelled = s.UserCancelled,
                        PaymentRecieved = s.PaymentRecieved,
                        StaffProcessed = s.StaffProcessed,
                        StaffCancelled = s.StaffCancelled,
                        SampleOutFordelivery = s.SampleOutFordelivery,

                    }).ToList();
                    BloodOrderrsp._bloodOrders = response;
                }
                BloodOrderrsp.Status = "Success";
                BloodOrderrsp.Msg = "Success";
                return BloodOrderrsp;
            }
            catch (Exception)
            {

                BloodOrderrsp.Status = "Fail";
                BloodOrderrsp.Msg = "Fail";
                return BloodOrderrsp;
            }
        }

        public BloodOrderResponse GetBloodOrder(int id)
        {
            BloodOrderResponse BloodOrderrsp = new BloodOrderResponse();
            try
            {
                BloodOrder? GetData = _context.BloodOrders.Include(d => d.PaymentDetails)
                   .Include(d => d.OrdeDeliveryDetails)
                   .Include(d => d.InventoryDetails)
                    .Where(s => s.Id == id).AsQueryable().FirstOrDefault();

                if (GetData != null)
                {
                    BloodOrderrsp._bloodOrder = GetData;
                }
                BloodOrderrsp.Status = "Success";
                BloodOrderrsp.Msg = "Success";
                return BloodOrderrsp;
            }
            catch (Exception)
            {
                BloodOrderrsp.Status = "Fail";
                BloodOrderrsp.Msg = "Fail";
                return BloodOrderrsp;
            }
        }
        public BloodOrderResponse AddBloodOrder(BloodOrder _bloodOrder)
        {
            BloodOrderResponse BloodOrderrsp = new BloodOrderResponse();
            try
            {
                var AddBloodOrder = _context.BloodOrders.Add(_bloodOrder);
                _context.SaveChanges();
                BloodOrderrsp.Status = "Success";
                BloodOrderrsp.Msg = "Success";
                BloodOrderrsp._bloodOrder = AddBloodOrder.Entity;
                return BloodOrderrsp;
            }
            catch (Exception)
            {
                BloodOrderrsp.Status = "Fail";
                BloodOrderrsp.Msg = "Fail";
                return BloodOrderrsp;
            }
        }

        public BloodOrderResponse UpdateBloodOrder(BloodOrder _bloodOrder)
        {

            BloodOrderResponse BloodOrderrsp = new BloodOrderResponse();
            try
            {
                BloodOrder? UpdateData = _context.BloodOrders.Include(d => d.PaymentDetails)
                   .Include(d => d.OrdeDeliveryDetails)
                   .Include(d => d.InventoryDetails)
                   .Where(s => s.Id == _bloodOrder.Id).AsQueryable().FirstOrDefault();
                if (UpdateData != null)
                {
                    UpdateData.UserManagementRowId = _bloodOrder.UserManagementRowId;
                    UpdateData.UserManagementId = _bloodOrder.UserManagementId;
                    UpdateData.BloodGroupTypeRowId = _bloodOrder.BloodGroupTypeRowId;
                    UpdateData.BloodGroupTypeId = _bloodOrder.BloodGroupTypeId;
                    UpdateData.NoOfUnitsAvailable = _bloodOrder.NoOfUnitsAvailable;
                    UpdateData.NoOfUnitsRequired = _bloodOrder.NoOfUnitsRequired;
                    UpdateData.UserRequested = _bloodOrder.UserRequested;
                    UpdateData.UserCancelled = _bloodOrder.UserCancelled;
                    UpdateData.PaymentRecieved = _bloodOrder.PaymentRecieved;
                    UpdateData.StaffProcessed = _bloodOrder.StaffProcessed;
                    UpdateData.StaffCancelled = _bloodOrder.StaffCancelled;
                    UpdateData.SampleOutFordelivery = _bloodOrder.SampleOutFordelivery;
                    UpdateData.RowId = _bloodOrder.RowId;
                    UpdateData.CreatedBy = _bloodOrder.CreatedBy;
                    UpdateData.ModifiedBy = _bloodOrder.ModifiedBy;
                    UpdateData.CreatedOn = _bloodOrder.CreatedOn;
                    UpdateData.ModifiedOn = _bloodOrder.ModifiedOn;
                    UpdateData.OrderBy = _bloodOrder.OrderBy;

                    if (UpdateData.PaymentDetails != null && _bloodOrder.PaymentDetails != null)
                    {
                        UpdateData.PaymentDetails.PaymentRecieved = _bloodOrder.PaymentDetails.PaymentRecieved;
                        UpdateData.PaymentDetails.PaymentCancelled = _bloodOrder.PaymentDetails.PaymentCancelled;
                        UpdateData.PaymentDetails.PaymentDate = _bloodOrder.PaymentDetails.PaymentDate;
                        UpdateData.PaymentDetails.PaymentAmount = _bloodOrder.PaymentDetails.PaymentAmount;
                        UpdateData.PaymentDetails.TransactionNumber = _bloodOrder.PaymentDetails.TransactionNumber;
                        UpdateData.PaymentDetails.TransactionDetails = _bloodOrder.PaymentDetails.TransactionDetails;
                        UpdateData.PaymentDetails.TransactionType = _bloodOrder.PaymentDetails.TransactionType;
                        UpdateData.PaymentDetails.TransactionCardDetails = _bloodOrder.PaymentDetails.TransactionCardDetails;
                        UpdateData.PaymentDetails.BloodOrderId = _bloodOrder.PaymentDetails.BloodOrderId;
                        UpdateData.PaymentDetails.RowId = _bloodOrder.PaymentDetails.RowId;
                        UpdateData.PaymentDetails.CreatedBy = _bloodOrder.PaymentDetails.CreatedBy;
                        UpdateData.PaymentDetails.ModifiedBy = _bloodOrder.PaymentDetails.ModifiedBy;
                        UpdateData.PaymentDetails.CreatedOn = _bloodOrder.PaymentDetails.CreatedOn;
                        UpdateData.PaymentDetails.ModifiedOn = _bloodOrder.PaymentDetails.ModifiedOn;
                        UpdateData.PaymentDetails.IsDeleted = _bloodOrder.PaymentDetails.IsDeleted;
                        UpdateData.PaymentDetails.OrderBy = _bloodOrder.PaymentDetails.OrderBy;
                    }
                    if (UpdateData.InventoryDetails != null && _bloodOrder.InventoryDetails != null)
                    {
                        UpdateData.InventoryDetails.InventoryNumber = _bloodOrder.InventoryDetails.InventoryNumber;
                        UpdateData.InventoryDetails.InventoryDate = _bloodOrder.InventoryDetails.InventoryDate;
                        UpdateData.InventoryDetails.BloodOrderId = _bloodOrder.InventoryDetails.BloodOrderId;
                        UpdateData.InventoryDetails.RowId = _bloodOrder.InventoryDetails.RowId;
                        UpdateData.InventoryDetails.CreatedBy = _bloodOrder.InventoryDetails.CreatedBy;
                        UpdateData.InventoryDetails.ModifiedBy = _bloodOrder.InventoryDetails.ModifiedBy;
                        UpdateData.InventoryDetails.CreatedOn = _bloodOrder.InventoryDetails.CreatedOn;
                        UpdateData.InventoryDetails.ModifiedOn = _bloodOrder.InventoryDetails.ModifiedOn;
                        UpdateData.InventoryDetails.IsDeleted = _bloodOrder.InventoryDetails.IsDeleted;
                        UpdateData.InventoryDetails.OrderBy = _bloodOrder.InventoryDetails.OrderBy;
                    }
                    if (UpdateData.OrdeDeliveryDetails != null && _bloodOrder.OrdeDeliveryDetails != null)
                    {
                        UpdateData.OrdeDeliveryDetails.OutFordelivery = _bloodOrder.OrdeDeliveryDetails.OutFordelivery;
                        UpdateData.OrdeDeliveryDetails.OutFordeliveryDate = _bloodOrder.OrdeDeliveryDetails.OutFordeliveryDate;
                        UpdateData.OrdeDeliveryDetails.DeliveryPersonDetails = _bloodOrder.OrdeDeliveryDetails.DeliveryPersonDetails;
                        UpdateData.OrdeDeliveryDetails.delivered = _bloodOrder.OrdeDeliveryDetails.delivered;
                        UpdateData.OrdeDeliveryDetails.DeliveryDate = _bloodOrder.OrdeDeliveryDetails.DeliveryDate;
                        UpdateData.OrdeDeliveryDetails.DeliveryOTP = _bloodOrder.OrdeDeliveryDetails.DeliveryOTP;
                        UpdateData.OrdeDeliveryDetails.BloodOrderId = _bloodOrder.OrdeDeliveryDetails.BloodOrderId;
                        UpdateData.OrdeDeliveryDetails.RowId = _bloodOrder.OrdeDeliveryDetails.RowId;
                        UpdateData.OrdeDeliveryDetails.CreatedBy = _bloodOrder.OrdeDeliveryDetails.CreatedBy;
                        UpdateData.OrdeDeliveryDetails.ModifiedBy = _bloodOrder.OrdeDeliveryDetails.ModifiedBy;
                        UpdateData.OrdeDeliveryDetails.CreatedOn = _bloodOrder.OrdeDeliveryDetails.CreatedOn;
                        UpdateData.OrdeDeliveryDetails.ModifiedOn = _bloodOrder.OrdeDeliveryDetails.ModifiedOn;
                        UpdateData.OrdeDeliveryDetails.IsDeleted = _bloodOrder.OrdeDeliveryDetails.IsDeleted;
                        UpdateData.OrdeDeliveryDetails.OrderBy = _bloodOrder.OrdeDeliveryDetails.OrderBy;
                    }
                    _context.SaveChanges();
                }

                BloodOrderrsp.Status = "Success";
                BloodOrderrsp.Msg = "Success";
                BloodOrderrsp._bloodOrder = UpdateData!;
                return BloodOrderrsp;
            }
            catch (Exception)
            {
                BloodOrderrsp.Status = "Fail";
                BloodOrderrsp.Msg = "Fail";
                return BloodOrderrsp;
            }
        }

        public BloodOrderResponse DeleteBloodOrder(BloodOrder _bloodOrder)
        {
            BloodOrderResponse BloodOrderrsp = new BloodOrderResponse();
            try
            {
                BloodOrder? DeleteData = _context.BloodOrders.Include(d => d.PaymentDetails)
                   .Include(d => d.OrdeDeliveryDetails)
                   .Include(d => d.InventoryDetails).Where(s => s.Id == _bloodOrder.Id).AsQueryable().FirstOrDefault();
                if (DeleteData != null)
                {

                    DeleteData.ModifiedBy = _bloodOrder.ModifiedBy;
                    DeleteData.ModifiedOn = _bloodOrder.ModifiedOn;
                    DeleteData.IsDeleted = _bloodOrder.IsDeleted;

                    if (DeleteData.PaymentDetails != null && _bloodOrder.PaymentDetails != null)
                    {
                        DeleteData.PaymentDetails.ModifiedBy = _bloodOrder.ModifiedBy;
                        DeleteData.PaymentDetails.ModifiedOn = DateTime.Now;
                        DeleteData.PaymentDetails.IsDeleted = true;

                    }
                    if (DeleteData.InventoryDetails != null && _bloodOrder.InventoryDetails != null)
                    {

                        DeleteData.InventoryDetails.ModifiedBy = _bloodOrder.ModifiedBy;
                        DeleteData.InventoryDetails.ModifiedOn = DateTime.Now;
                        DeleteData.InventoryDetails.IsDeleted = true;
                    }
                    if (DeleteData.OrdeDeliveryDetails != null && _bloodOrder.OrdeDeliveryDetails != null)
                    {
                        DeleteData.OrdeDeliveryDetails.ModifiedBy = _bloodOrder.ModifiedBy;
                        DeleteData.OrdeDeliveryDetails.ModifiedOn = DateTime.Now;
                        DeleteData.OrdeDeliveryDetails.IsDeleted = true;
                    }
                    _context.SaveChanges();
                }

                BloodOrderrsp.Status = "Success";
                BloodOrderrsp.Msg = "Success";
                BloodOrderrsp._bloodOrder = DeleteData!;
                return BloodOrderrsp;
            }
            catch (Exception)
            {
                BloodOrderrsp.Status = "Fail";
                BloodOrderrsp.Msg = "Fail";
                return BloodOrderrsp;
            }
        }
    }
}
