﻿namespace BBMS.Constatnts
{
    public static class UserProfile
    {
        public static string? UserName { get; set; }
        public static string? Emailid { get; set; }
        public static long? RoleId { get; set; }
        public static string? RoleName { get; set; }
        public static long? UserId { get; set; }
    }
}
