﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BBMS.Data;
using BBMS.Models;

namespace BBMS.Controllers
{
    public class BloodGroupTypesController : Controller
    {
        private readonly BBMSDataContext _context;

        public BloodGroupTypesController(BBMSDataContext context)
        {
            _context = context;
        }

        // GET: BloodGroupTypes
        public async Task<IActionResult> Index()
        {
              return _context.BloodGroupTypes != null ? 
                          View(await _context.BloodGroupTypes.Where(s => !s.IsDeleted).ToListAsync()) :
                          Problem("Entity set 'BBMSDataContext.BloodGroupTypes'  is null.");
        }

        // GET: BloodGroupTypes/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null || _context.BloodGroupTypes == null)
            {
                return NotFound();
            }

            var bloodGroupType = await _context.BloodGroupTypes.Where(s=>!s.IsDeleted)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bloodGroupType == null)
            {
                return NotFound();
            }

            return View(bloodGroupType);
        }

        // GET: BloodGroupTypes/Create
        public IActionResult Create()
        {
            BloodGroupType bloodGroupType = new BloodGroupType();
            return View(bloodGroupType);
        }

        // POST: BloodGroupTypes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("GroupName,BloodUnits,Id,RowId,CreatedBy,ModifiedBy,CreatedOn,ModifiedOn,IsDeleted,OrderBy")] BloodGroupType bloodGroupType)
        {
            if (ModelState.IsValid)
            {
                bloodGroupType.CreatedBy = "Administrator";
                bloodGroupType.ModifiedBy = "Administrator";
                _context.Add(bloodGroupType);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(bloodGroupType);
        }

        // GET: BloodGroupTypes/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null || _context.BloodGroupTypes == null)
            {
                return NotFound();
            }

            var bloodGroupType = await _context.BloodGroupTypes.FindAsync(id);
            if (bloodGroupType == null)
            {
                return NotFound();
            }
            return View(bloodGroupType);
        }

        // POST: BloodGroupTypes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(long id, [Bind("GroupName,BloodUnits,Id,RowId,CreatedBy,ModifiedBy,CreatedOn,ModifiedOn,IsDeleted,OrderBy")] BloodGroupType bloodGroupType)
        {
            if (id != bloodGroupType.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    bloodGroupType.ModifiedOn = DateTime.Now;
                    bloodGroupType.ModifiedBy = "Administrator";
                    _context.Update(bloodGroupType);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BloodGroupTypeExists(bloodGroupType.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(bloodGroupType);
        }

        // GET: BloodGroupTypes/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null || _context.BloodGroupTypes == null)
            {
                return NotFound();
            }

            var bloodGroupType = await _context.BloodGroupTypes
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bloodGroupType == null)
            {
                return NotFound();
            }

            return View(bloodGroupType);
        }

        // POST: BloodGroupTypes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long id)
        {
            if (_context.BloodGroupTypes == null)
            {
                return Problem("Entity set 'BBMSDataContext.BloodGroupTypes'  is null.");
            }
            var bloodGroupType = await _context.BloodGroupTypes.FindAsync(id);
            if (bloodGroupType != null)
            {
                bloodGroupType.IsDeleted = true;
                bloodGroupType.ModifiedOn = DateTime.Now;
                bloodGroupType.ModifiedBy = "Administrator";
                // _context.BloodGroupTypes.Remove(bloodGroupType);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BloodGroupTypeExists(long id)
        {
          return (_context.BloodGroupTypes?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
