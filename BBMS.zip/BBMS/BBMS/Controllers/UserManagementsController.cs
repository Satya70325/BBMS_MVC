﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BBMS.Data;
using BBMS.Models;
using BBMS.Constatnts;

namespace BBMS.Controllers
{
    public class UserManagementsController : Controller
    {
        private readonly BBMSDataContext _context;

        public UserManagementsController(BBMSDataContext context)
        {
            _context = context;
        }

        // GET: UserManagements
        public async Task<IActionResult> Index()
        {
            var bBMSDataContext = _context.UserManagements.Where(s=>!s.IsDeleted).Include(u => u.UserRoles);            
            return View(await bBMSDataContext.ToListAsync());
        }

        // GET: UserManagements/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null || _context.UserManagements == null)
            {
                return NotFound();
            }

            var userManagement = await _context.UserManagements
                .Include(u => u.UserRoles)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (userManagement == null)
            {
                return NotFound();
            }

            return View(userManagement);
        }

        // GET: UserManagements/Create
        public IActionResult Create()
        {
            UserManagement userManagement = new UserManagement();
            ViewData["UserRoleId"] = new SelectList(_context.UserRoles.Where(s=>!s.IsDeleted), "Id", "RoleName");
            return View(userManagement);
        }

        // POST: UserManagements/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UserRoleRowId,UserRoleId,FirstName,MiddleName,LastName,PrimaryMobile,SecondaryMobile,PrimaryEmail,SecondaryEmail,Address1,Address2,Address3,PinCode,UserName,PassWord,Id,RowId,CreatedBy,ModifiedBy,CreatedOn,ModifiedOn,IsDeleted,OrderBy")] UserManagement userManagement)
        {
            if (ModelState.IsValid)
            {
                if(!string.IsNullOrEmpty(UserProfile.UserName))
                {
                    userManagement.CreatedBy = UserProfile.UserName;
                    userManagement.ModifiedBy = UserProfile.UserName;
                }
                else
                {
                    userManagement.CreatedBy = "Administrator";
                    userManagement.ModifiedBy = "Administrator";
                }
                var UserFound = await _context.UserManagements.Where(s=>s.UserName== userManagement.UserName).FirstOrDefaultAsync();
                if (UserFound == null)
                {
                    
                  var usrroles=await _context.UserRoles.Where(s => s.Id == userManagement.UserRoleId).FirstOrDefaultAsync();
                    userManagement.UserRoleRowId = usrroles!.RoleId;
                  _context.Add(userManagement);
                    await _context.SaveChangesAsync();
                    if (string.IsNullOrEmpty(UserProfile.UserName))
                    {
                        return RedirectToAction("Index", "Login");
                    }
                    else
                    {
                        return RedirectToAction(nameof(Index));
                    }
                }
                else
                {
                    ViewBag.Message = "User Already Exists";
                   
                    
                }
            }

            List<UserRole> roles = _context.UserRoles.ToList();
            ViewData["UserRoleId"] = new SelectList(roles, "Id", "RoleName", userManagement.UserRoleId);
            return View(userManagement);
        }

        // GET: UserManagements/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null || _context.UserManagements == null)
            {
                return NotFound();
            }

            var userManagement = await _context.UserManagements.FindAsync(id);
            if (userManagement == null)
            {
                return NotFound();
            }
            List<UserRole> roles = _context.UserRoles.ToList();

            ViewData["UserRoleId"] = new SelectList(roles, "Id", "RoleName", userManagement.UserRoleId);
            return View(userManagement);
        }

        // POST: UserManagements/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(long id, [Bind("UserRoleRowId,UserRoleId,FirstName,MiddleName,LastName,PrimaryMobile,SecondaryMobile,PrimaryEmail,SecondaryEmail,Address1,Address2,Address3,PinCode,UserName,PassWord,Id,RowId,CreatedBy,ModifiedBy,CreatedOn,ModifiedOn,IsDeleted,OrderBy")] UserManagement userManagement)
        {
            List<UserRole> roles = _context.UserRoles.ToList();
            if (id != userManagement.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (!string.IsNullOrEmpty(UserProfile.UserName))
                    {
                        userManagement.ModifiedOn = DateTime.Now;
                        userManagement.ModifiedBy = UserProfile.UserName;
                    }
                    else
                    {
                        userManagement.ModifiedOn = DateTime.Now;
                        userManagement.ModifiedBy = "Administrator";
                    }
                    var UserFound = await _context.UserManagements.Where(s => s.UserName == userManagement.UserName && s.Id!=userManagement.Id).FirstOrDefaultAsync();
                    if (UserFound == null)
                    {
                        var usrroles = await _context.UserRoles.Where(s => s.Id == userManagement.UserRoleId).FirstOrDefaultAsync();
                        userManagement.UserRoleRowId = usrroles!.RoleId;
                        _context.Update(userManagement);
                        await _context.SaveChangesAsync();
                    }
                    else
                    {
                        ViewBag.Message = "User Already Exists";
                        ViewData["UserRoleId"] = new SelectList(roles, "Id", "RoleName", userManagement.UserRoleId);
                        return View(userManagement);
                    }
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserManagementExists(userManagement.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            
            ViewData["UserRoleId"] = new SelectList(roles, "Id", "RoleName", userManagement.UserRoleId);
            return View(userManagement);
        }

        // GET: UserManagements/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null || _context.UserManagements == null)
            {
                return NotFound();
            }

            var userManagement = await _context.UserManagements
                .Include(u => u.UserRoles)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (userManagement == null)
            {
                return NotFound();
            }

            return View(userManagement);
        }

        // POST: UserManagements/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long id)
        {
            if (_context.UserManagements == null)
            {
                return Problem("Entity set 'BBMSDataContext.UserManagements'  is null.");
            }
            var userManagement = await _context.UserManagements.FindAsync(id);
            if (userManagement != null)
            {
                if (!string.IsNullOrEmpty(UserProfile.UserName))
                {
                    userManagement.ModifiedOn = DateTime.Now;
                    userManagement.ModifiedBy = UserProfile.UserName;
                }
                else
                {
                    userManagement.ModifiedOn = DateTime.Now;
                    userManagement.ModifiedBy = "Administrator";
                }
                userManagement.IsDeleted = true;
                _context.Update(userManagement);
                await _context.SaveChangesAsync();
                // _context.UserManagements.Remove(userManagement);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool UserManagementExists(long id)
        {
          return (_context.UserManagements?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
