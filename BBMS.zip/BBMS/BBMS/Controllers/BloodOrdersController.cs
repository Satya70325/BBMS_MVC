﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BBMS.Data;
using BBMS.Models;
using BBMS.Constatnts;

namespace BBMS.Controllers
{
    public class BloodOrdersController : Controller
    {
        private readonly BBMSDataContext _context;

        public BloodOrdersController(BBMSDataContext context)
        {
            _context = context;
        }

        // GET: BloodOrders
        public async Task<IActionResult> Index()
        {
            if (UserProfile.RoleId == 1 || UserProfile.RoleId == 2)
            {
                var bBMSDataContext = _context.BloodOrders.Where(s => !s.IsDeleted).Include(b => b.BloodGroupTypes).Include(b => b.UserManagements);
                return View(await bBMSDataContext.ToListAsync());
               
            }
            else
            {
                if (UserProfile.RoleId == 4)
                {
                    var bBMSDataContext = _context.BloodOrders.Where(s => !s.IsDeleted && s.UserManagementId == UserProfile.UserId).Include(b => b.BloodGroupTypes).Include(b => b.UserManagements);
                    return View(await bBMSDataContext.ToListAsync());
                }
                else
                {
                    return View(new List<BloodOrder>());
                }
            }
        }

        // GET: BloodOrders/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null || _context.BloodOrders == null)
            {
                return NotFound();
            }

            var bloodOrder = await _context.BloodOrders
                .Include(b => b.BloodGroupTypes)
                .Include(b => b.UserManagements)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bloodOrder == null)
            {
                return NotFound();
            }

            return View(bloodOrder);
        }

        // GET: BloodOrders/Create
        public IActionResult Create()
        {
            BloodOrder bloodOrder = new BloodOrder();
            bloodOrder.UserManagementId = UserProfile.UserId;
            ViewData["BloodGroupTypeId"] = new SelectList(_context.BloodGroupTypes.Where(s => !s.IsDeleted), "Id", "GroupName");
            ViewData["UserManagementId"] = new SelectList(_context.UserManagements.Where(s => !s.IsDeleted), "Id", "FirstName");
            return View(bloodOrder);
        }

        // POST: BloodOrders/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create( BloodOrder bloodOrder)
        {
            if (ModelState.IsValid)
            {
                if (!string.IsNullOrEmpty(UserProfile.UserName))
                {
                    bloodOrder.CreatedBy = UserProfile.UserName;
                    bloodOrder.ModifiedBy = UserProfile.UserName;

                    bloodOrder.PaymentDetails!.CreatedBy = UserProfile.UserName;
                    bloodOrder.PaymentDetails!.ModifiedBy = UserProfile.UserName;

                    bloodOrder.InventoryDetails!.CreatedBy = UserProfile.UserName;
                    bloodOrder.InventoryDetails!.ModifiedBy = UserProfile.UserName;

                    bloodOrder.OrdeDeliveryDetails!.CreatedBy = UserProfile.UserName;
                    bloodOrder.OrdeDeliveryDetails!.ModifiedBy = UserProfile.UserName;
                }
                else
                {
                    bloodOrder.CreatedBy = "Administrator";
                    bloodOrder.ModifiedBy = "Administrator";

                    bloodOrder.PaymentDetails!.CreatedBy = "Administrator";
                    bloodOrder.PaymentDetails!.ModifiedBy = "Administrator";

                    bloodOrder.InventoryDetails!.CreatedBy = "Administrator";
                    bloodOrder.InventoryDetails!.ModifiedBy = "Administrator";

                    bloodOrder.OrdeDeliveryDetails!.CreatedBy = "Administrator";
                    bloodOrder.OrdeDeliveryDetails!.ModifiedBy = "Administrator";
                }

                var bgGrps = await _context.BloodGroupTypes.Where(s => s.Id == bloodOrder.BloodGroupTypeId).FirstOrDefaultAsync();
                bloodOrder.BloodGroupTypeRowId = bgGrps!.RowId;

                var UserGrps = await _context.UserManagements.Where(s => s.Id == bloodOrder.UserManagementId).FirstOrDefaultAsync();
                bloodOrder.UserManagementRowId = UserGrps!.RowId;
                bloodOrder.UserRequested = true;
                bloodOrder.PaymentRecieved = true;

                bloodOrder.PaymentDetails.PaymentRecieved = true;
                bloodOrder.PaymentDetails.PaymentDate = DateTime.Now;
                bloodOrder.PaymentDetails.TransactionNumber = Guid.NewGuid().ToString();
                bloodOrder.PaymentDetails.TransactionDetails = Guid.NewGuid().ToString();
                bloodOrder.PaymentDetails.TransactionType = "Online";
                bloodOrder.PaymentDetails.TransactionCardDetails = Guid.NewGuid().ToString();

                _context.Add(bloodOrder);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["BloodGroupTypeId"] = new SelectList(_context.BloodGroupTypes.Where(s => !s.IsDeleted), "Id", "GroupName", bloodOrder.BloodGroupTypeId);
            ViewData["UserManagementId"] = new SelectList(_context.UserManagements.Where(s => !s.IsDeleted), "Id", "FirstName", bloodOrder.UserManagementId);
            return View(bloodOrder);
        }

        // GET: BloodOrders/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null || _context.BloodOrders == null)
            {
                return NotFound();
            }

            var bloodOrder = await _context.BloodOrders.Include(b => b.BloodGroupTypes)
                .Include(b => b.UserManagements)
                .Include(b => b.PaymentDetails)
                .Include(b => b.InventoryDetails)
                .Include(b => b.OrdeDeliveryDetails).
                FirstOrDefaultAsync(m => m.Id == id);
            if (bloodOrder == null)
            {
                return NotFound();
            }
            ViewData["BloodGroupTypeId"] = new SelectList(_context.BloodGroupTypes.Where(s => !s.IsDeleted), "Id", "GroupName", bloodOrder.BloodGroupTypeId);
            ViewData["UserManagementId"] = new SelectList(_context.UserManagements.Where(s => !s.IsDeleted), "Id", "FirstName", bloodOrder.UserManagementId);
            return View(bloodOrder);
        }

        // POST: BloodOrders/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(long id, BloodOrder bloodOrder)
        {
            if (id != bloodOrder.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (!string.IsNullOrEmpty(UserProfile.UserName))
                    {
                        bloodOrder.ModifiedOn = DateTime.Now;
                        bloodOrder.ModifiedBy = UserProfile.UserName;


                        bloodOrder.PaymentDetails!.ModifiedOn = DateTime.Now;
                        bloodOrder.PaymentDetails!.ModifiedBy = UserProfile.UserName;

                        bloodOrder.InventoryDetails!.ModifiedOn = DateTime.Now;
                        bloodOrder.InventoryDetails!.ModifiedBy = UserProfile.UserName;

                        bloodOrder.OrdeDeliveryDetails!.ModifiedOn = DateTime.Now;
                        bloodOrder.OrdeDeliveryDetails!.ModifiedBy = UserProfile.UserName;
                    }
                    else
                    {
                        bloodOrder.ModifiedOn = DateTime.Now;
                        bloodOrder.ModifiedBy = "Administrator";

                        bloodOrder.PaymentDetails!.ModifiedOn = DateTime.Now;
                        bloodOrder.PaymentDetails!.ModifiedBy = "Administrator";

                        bloodOrder.InventoryDetails!.ModifiedOn = DateTime.Now;
                        bloodOrder.InventoryDetails!.ModifiedBy = "Administrator";

                        bloodOrder.OrdeDeliveryDetails!.ModifiedOn = DateTime.Now;
                        bloodOrder.OrdeDeliveryDetails!.ModifiedBy = "Administrator";
                    }


                    var bgGrps = await _context.BloodGroupTypes.Where(s => s.Id == bloodOrder.BloodGroupTypeId).FirstOrDefaultAsync();
                    bloodOrder.BloodGroupTypeRowId = bgGrps!.RowId;

                    var UserGrps = await _context.UserManagements.Where(s => s.Id == bloodOrder.UserManagementId).FirstOrDefaultAsync();
                    bloodOrder.UserManagementRowId = UserGrps!.RowId;

                    bloodOrder.OrdeDeliveryDetails!.OutFordelivery = true;
                    bloodOrder.OrdeDeliveryDetails!.DeliveryOTP = "1234";

                    bloodOrder.SampleOutFordelivery = true;
                    bloodOrder.StaffProcessed = true;

                    _context.Update(bloodOrder);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BloodOrderExists(bloodOrder.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["BloodGroupTypeId"] = new SelectList(_context.BloodGroupTypes.Where(s => !s.IsDeleted), "Id", "GroupName", bloodOrder.BloodGroupTypeId);
            ViewData["UserManagementId"] = new SelectList(_context.UserManagements.Where(s => !s.IsDeleted), "Id", "FirstName", bloodOrder.UserManagementId);
            return View(bloodOrder);
        }

        // GET: BloodOrders/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null || _context.BloodOrders == null)
            {
                return NotFound();
            }

            var bloodOrder = await _context.BloodOrders
                .Include(b => b.BloodGroupTypes)
                .Include(b => b.UserManagements)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bloodOrder == null)
            {
                return NotFound();
            }

            return View(bloodOrder);
        }

        // POST: BloodOrders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long id)
        {
            if (_context.BloodOrders == null)
            {
                return Problem("Entity set 'BBMSDataContext.BloodOrders'  is null.");
            }
            var bloodOrder = await _context.BloodOrders.FindAsync(id);
            if (bloodOrder != null)
            {
                _context.BloodOrders.Remove(bloodOrder);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BloodOrderExists(long id)
        {
            return (_context.BloodOrders?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
